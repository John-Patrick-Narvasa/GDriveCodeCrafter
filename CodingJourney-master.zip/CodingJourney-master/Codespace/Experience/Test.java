package Experience;

public class Test {
    public static void main(String[] args) {
        Tools.print("Bruh");

        Tools.upper("Brother");

        

    }

    
}

