package Experience;
public class Tools {
    public static void print(String s) {
        System.out.println(s);
        // no more return cuz void obviously
    }

    public static void upper(String s) {
        System.out.println(s.toUpperCase());
    }
}
