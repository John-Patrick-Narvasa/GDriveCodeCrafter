package Java.Tests;

import java.util.Scanner;


public class PlayGround {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int num;

        while (true) {
            try {
                if (num == 0) {

                }
                else if (num < 0) {

                }
                else {
                    for ()
                }
            }
            catch (NumberFormatException e) {
                System.out.println("Invalid input, please enter a number");
            }
        }
    }
}
