package Java.Tutorials.Basics.Methods;
public class ArithmeticTricks  {
    public static void main(String[] args) {
        //arithmetic tricks

            //augmented assignment 
            double x = 1;
            x /= 4;
    
            //post and pre increment
            int y = 1;
            int z = y++; //1 will be 2
    
            int a = 1; //1 will be 2
            int b = ++a;
    
            System.out.println(x);
            System.out.println(y);
            System.out.println(a);
    }
}
