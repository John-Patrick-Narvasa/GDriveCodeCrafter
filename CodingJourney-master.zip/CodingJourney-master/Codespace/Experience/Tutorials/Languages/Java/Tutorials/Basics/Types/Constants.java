package Java.Tutorials.Basics.Types;

public class Constants  {
    public static void main(String[] args) {
        //PI constant
        final float PIconstant = 3.14F;
        System.out.println(PIconstant);
        //e constant
        final float Econstant = 2.73F;
        System.out.println(Econstant);

    }
}
