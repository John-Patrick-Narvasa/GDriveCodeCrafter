# Java tutorials source:

## Functions


    * smallest building block of code
    * block of code that performs a singular task (example: each buttons of the remote control TV, converting pounds to kilograms,)
    *

    Structure:
    FUNCTION(*insert parameters)
        - if no parameters, it only outputs singular standard result

Code terms
    ```
    ReturnType sendEmail() {
        *insert the code for functionality
    }

    void main() {
        *insert the code        **These built in functions don't exist on their own 
    }
    ```

## Class