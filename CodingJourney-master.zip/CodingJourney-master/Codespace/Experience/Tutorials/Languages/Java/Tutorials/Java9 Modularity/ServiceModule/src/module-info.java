module ServiceModule {

    exports service.process;
    requires RepositoryModule;
}