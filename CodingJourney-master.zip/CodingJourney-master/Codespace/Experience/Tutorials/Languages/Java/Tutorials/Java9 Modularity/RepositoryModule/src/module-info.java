module RepositoryModule {

    exports repository to ServiceModule;
}