module UIModule {

    requires ServiceModule;
    requires RepositoryModule;
}