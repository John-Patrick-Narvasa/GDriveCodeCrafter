package Java.Tutorials.Translation.TriviaQuizSample;


import java.util.random.*;
public class Questionnaires {
    public 
    
}
