package Java.Tutorials.Basics.Types;
import java.util.Arrays;

public class ArraysBasic  {
    public static void main(String[] args) {
        int[] numbers = new int[5];
        numbers[0] = 1;
        numbers[1] = 2;

        System.out.println(Arrays.toString(numbers)); 
    }
}
