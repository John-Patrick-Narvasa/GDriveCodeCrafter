

user_name=input('enter your name')

print('your name is: ',user_name)  

age=input('how old are you?')

print('your age is: ',age)  
