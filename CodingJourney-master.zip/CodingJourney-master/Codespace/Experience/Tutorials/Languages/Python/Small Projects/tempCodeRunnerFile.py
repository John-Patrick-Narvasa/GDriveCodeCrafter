x = "Brother Carl"

#print(len(x))
#print(x.find("h"))
#print(x.capitalize())
#print(x.upper())
#print(x.isdigit())
#print(x.lower())
print(x.find("h"))