
income = 10000
credit = 100000
criminal = True

if income > 50000 or credit and not criminal:
    print("eligible for loan")
else:
    print("not eligible")