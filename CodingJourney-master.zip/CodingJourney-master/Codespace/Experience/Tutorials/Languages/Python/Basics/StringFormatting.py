firstName = "John"
lastName = "Doe"
fullName = firstName + " " + lastName
print(fullName + " is my name bro")