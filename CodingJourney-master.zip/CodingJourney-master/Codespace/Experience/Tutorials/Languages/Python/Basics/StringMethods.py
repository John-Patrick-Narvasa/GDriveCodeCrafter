char = 'This is a sample character or string'

print(char)
print(len(char))
print(char.capitalize())
print(char.upper())
print(char.lower())
print(char.title())

print(char.find('a'))
print(char.replace('This', 'That'))
#returns boolean value
print(char.isdigit()) #returns true or false if it is a number
print('This'in char) # (object BELONGS IN variable)

char.capitalize()

#methods has basic structures
    # 1. method(arguments/objects)
    # 2. object.method()

