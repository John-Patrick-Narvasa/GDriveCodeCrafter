import math # now we can use math functions

x = 2.9

print(round(x)) # 3

print(abs(-2.9)) # 2.9

print(pow(3, 2)) # 9

print(math.sqrt(36)) # 6

print(math.ceil(x)) # 3

print (math.factorial(5))

print(math.pi) # 3.141592653589793