
print(10 + 3) # 13 sum
print(10 - 3) # 7 difference
print(10 * 3) # 30 product
print(10 / 3) # 3.333333333333333 quotient
print(10 // 3) # 3 quotient without decimal
print(10 % 3) # 1 (remainder) 
print(10 ** 3) # 10000  (10 to the power of 3)

x = 10
x = x + 3 # variable reassignment

# OR
# x += 3

print(x) # 13