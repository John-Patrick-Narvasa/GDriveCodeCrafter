
print("Hello, World!")