name = "World"

def greet(name):
    print("Hello, " + name)


print(greet(name))