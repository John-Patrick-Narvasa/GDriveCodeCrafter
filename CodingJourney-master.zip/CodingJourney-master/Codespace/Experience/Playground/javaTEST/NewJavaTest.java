public class NewJavaTest {
    public static void main(String[] args) {
        System.out.println("Testing...");
        System.out.println("Testing 2...");
    }
}