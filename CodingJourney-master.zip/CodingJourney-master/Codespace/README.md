# Coding Journey
this is where I put every ideas in unsorted manner

## Goal
  - [ ]  Advance the basics of Java (Function/Methods, OOP, Control Flow, Modules)
    - [ ]  Use built-ins and create ur own
  - [ ]  Recursion And DSA (soon) (September)
  - [ ]  Make scripts for automating messages (Test on my own profile in messenger)

## What to put right now
  - [ ]  small learning projects
    - [ ]  Calculator in Java
    - [ ]  Trivia Quiz (With Randomizer, DB, )
    - [ ]  Recreate Excel Functions via Java
    - [ ]  To Do Lists
    - [ ]  School Org Sys Web (w/API application)

  - [ ]  small learning projects
    - [ ]  Calculator in Java
    - [ ]  Trivia Quiz (With Randomizer, DB, )
    - [ ]  Recreate Excel Functions via Java
    - [ ]  To Do Lists
    - [ ]  School Org Sys Web (w/API application)
    
   
  ### Resources
   - [ ]  Book (pictures) -> exercises and standard processes
   - [ ]  Encode (from phone)
   - [ ]  YT (from phone)
   - [ ]  Simplilearn (Java, Javascript)
   - [ ]  Github Tutorials from D:\_College Resource\Misc\GitHub tuts
   - [ ]  Prog exercises (from GPT)