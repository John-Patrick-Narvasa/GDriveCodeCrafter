package _SchoolStuff.Task.Finals;
import java.util.Scanner;
public class _Finals {

    // main method
    public static void main(String[] args) {
        //declaration
        Scanner input = new Scanner (System.in);

        // main loop
            // w/ conditions to end loop

        //closing method
        input.close();
    }

    // intro methods

    // main logic (w/ arrays, loops and functions)

    // main outputs display

    // end loop method

    // closing method

}
