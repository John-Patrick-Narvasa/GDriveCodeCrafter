package _SchoolStuff.Study.LoopStructures;

//purpose: reverse version of do while loop

public class Dowhile {

	public static void main(String[] args) { //needs terminator
		int x = 0;
		
		do {
			System.out.println("I love do while loops");
			x++;
		}
		while (x < 10); // as long as if its true, activate the "do" block

	}

}
