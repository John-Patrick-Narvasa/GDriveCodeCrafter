package _SchoolStuff.Study;

public class Arithmetics2 {
    public static void main(String[] args) {
        int x = 3;
        System.out.println(x++ * 2 + ++x);
    }
}