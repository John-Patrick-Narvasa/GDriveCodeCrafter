package JAVA.Projects.Sudoku.constants;

public class Messages {
    public static final String GAME_COMPLETE = "Congratulations, you have won! New Game?";
    public static final String ERROR = "An error has occurred";
    public static final String GAME_OVER = "Game Over. New Game?";

    
}
