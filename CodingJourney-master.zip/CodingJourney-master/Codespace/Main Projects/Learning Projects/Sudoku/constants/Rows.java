package JAVA.Projects.Sudoku.constants;

public class Rows {
    TOP,
    MIDDLE,
    BOTTOM
    
}
