package JAVA.Projects.Sudoku.constants;

public class GameState {
    COMPLETE,
    ACTIVE,
    NEW
}
