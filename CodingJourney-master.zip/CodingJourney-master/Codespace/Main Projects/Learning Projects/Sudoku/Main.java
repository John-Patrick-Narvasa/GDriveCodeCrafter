package JAVA.Projects.Sudoku;

public class Main {
    public static void main(String[] args) {
        SudokuApplication.main(new String[]{});
    }
}
